#!/usr/bin/env sh
./gradlew build shadowJar
